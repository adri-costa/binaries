package com.appsec.projetoconjur.backend.config;

import com.cyberark.conjur.api.Conjur;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

@Component
public class ConjurSslConfig implements WebServerFactoryCustomizer<TomcatServletWebServerFactory> {

    private static final Logger logger = LoggerFactory.getLogger(ConjurSslConfig.class);
    private final Conjur conjurClient;
    private static final String CERT_DIR = "src/main/resources/certs/";

    public ConjurSslConfig(Conjur conjurClient) {
        this.conjurClient = conjurClient;
    }

    @Override
    public void customize(TomcatServletWebServerFactory factory) {
        logger.info("🔒 Configurando HTTPS via certificados armazenados no Conjur...");

        try {
            // 🔹 Criar diretório de certificados se não existir
            File certDir = new File(CERT_DIR);
            if (!certDir.exists()) {
                certDir.mkdirs();
            }

            // 🔹 Buscar senhas a partir das variáveis de ambiente
            String keystorePassword = System.getenv("CONJUR_KEYSTORE_PASSWORD");
            String truststorePassword = System.getenv("CONJUR_TRUSTSTORE_PASSWORD");

            if (keystorePassword == null || keystorePassword.isEmpty()) {
                throw new RuntimeException("❌ A variável de ambiente CONJUR_KEYSTORE_PASSWORD não está definida!");
            }

            if (truststorePassword == null || truststorePassword.isEmpty()) {
                throw new RuntimeException("❌ A variável de ambiente CONJUR_TRUSTSTORE_PASSWORD não está definida!");
            }

            logger.info("🔍 Senha do Keystore e Truststore obtidas via variáveis de ambiente.");

            // 🔹 Buscar certificados armazenados no Conjur
            String certPem = getConjurSecret("certificates/backend-ms-a/cert");
            String keyPem = getConjurSecret("certificates/backend-ms-a/key");
            String caCertPem = getConjurSecret("certificates/ca/cert");

            // 🔹 Criar os Keystores e salvar no classpath (resources/certs/)
            File keyStoreFile = saveKeystore(createKeyStore(certPem, keyPem, "backend-ms-a", keystorePassword),
                    CERT_DIR + "keystore.p12", keystorePassword);
            File trustStoreFile = saveKeystore(createTrustStore(caCertPem),
                    CERT_DIR + "truststore.p12", truststorePassword);

            // 🔹 Configurar propriedades do Spring Boot dinamicamente
            System.setProperty("server.ssl.key-store", keyStoreFile.getAbsolutePath());
            System.setProperty("server.ssl.key-store-password", keystorePassword);
            System.setProperty("server.ssl.key-store-type", "PKCS12");

            System.setProperty("server.ssl.trust-store", trustStoreFile.getAbsolutePath());
            System.setProperty("server.ssl.trust-store-password", truststorePassword);
            System.setProperty("server.ssl.trust-store-type", "PKCS12");

            logger.info("✅ HTTPS configurado com sucesso! Keystore e Truststore salvos em {}", CERT_DIR);
        } catch (Exception e) {
            logger.error("❌ Erro ao configurar o SSL", e);
            throw new RuntimeException("❌ Erro ao configurar o SSL", e);
        }
    }

    private String getConjurSecret(String variableId) {
        try {
            logger.info("🔍 Consultando variável no Conjur: {}", variableId);
            String secret = conjurClient.variables().retrieveSecret(variableId);

            if (secret == null || secret.isEmpty()) {
                throw new RuntimeException("❌ A variável " + variableId + " não foi encontrada ou está vazia!");
            }

            logger.info("✅ Variável {} recuperada com sucesso!", variableId);
            return secret.strip(); // Remover quebras de linha invisíveis
        } catch (Exception e) {
            logger.error("❌ Erro ao buscar variável do Conjur: {}", e.getMessage(), e);
            throw new RuntimeException("Erro ao recuperar variável do Conjur: " + variableId, e);
        }
    }

    private KeyStore createKeyStore(String certPem, String keyPem, String alias, String keystorePassword) throws Exception {
        logger.info("📌 Criando KeyStore para {}...", alias);

        try {
            KeyStore keyStore = KeyStore.getInstance("PKCS12");
            keyStore.load(null, null);

            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            Certificate cert = certFactory.generateCertificate(new ByteArrayInputStream(certPem.getBytes(StandardCharsets.UTF_8)));

            byte[] keyBytes = decodePemPrivateKey(keyPem);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PrivateKey privateKey = keyFactory.generatePrivate(new PKCS8EncodedKeySpec(keyBytes));

            keyStore.setKeyEntry(alias, privateKey, keystorePassword.toCharArray(), new Certificate[]{cert});

            logger.info("✅ KeyStore criado com sucesso para {}.", alias);
            return keyStore;
        } catch (Exception e) {
            logger.error("❌ Erro ao criar Keystore para {}", alias, e);
            throw new RuntimeException("Erro ao criar Keystore", e);
        }
    }

    private KeyStore createTrustStore(String caCertPem) throws Exception {
        logger.info("📌 Criando TrustStore...");

        try {
            KeyStore trustStore = KeyStore.getInstance("PKCS12");
            trustStore.load(null, null);

            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
            Certificate caCert = certFactory.generateCertificate(new ByteArrayInputStream(caCertPem.getBytes(StandardCharsets.UTF_8)));

            trustStore.setCertificateEntry("ca-cert", caCert);

            logger.info("✅ TrustStore criado com sucesso.");
            return trustStore;
        } catch (Exception e) {
            logger.error("❌ Erro ao criar TrustStore", e);
            throw new RuntimeException("Erro ao criar TrustStore", e);
        }
    }

    private byte[] decodePemPrivateKey(String pem) {
        try {
            String privateKeyPEM = pem
                    .replaceAll("-----BEGIN PRIVATE KEY-----", "")
                    .replaceAll("-----END PRIVATE KEY-----", "")
                    .replaceAll("\\s+", "");

            return Base64.getDecoder().decode(privateKeyPEM);
        } catch (Exception e) {
            logger.error("❌ Erro ao decodificar a chave privada PEM", e);
            throw new RuntimeException("Erro ao decodificar a chave privada PEM", e);
        }
    }

    private File saveKeystore(KeyStore keyStore, String filePath, String password) throws Exception {
        File file = new File(filePath);

        try (FileOutputStream fos = new FileOutputStream(file)) {
            keyStore.store(fos, password.toCharArray());
        }

        logger.info("✅ Keystore salvo em: {}", file.getAbsolutePath());
        return file;
    }
}
