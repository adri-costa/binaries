package com.appsec.projetoconjur.backend.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.InputStream;
import java.net.URL;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/")
public class CredentialController {

    private static final Logger logger = LoggerFactory.getLogger(CredentialController.class);

    private static final Map<String, String> STATUS = new HashMap<>();

    static {
        STATUS.put("backend-ms-a", "Em Execução");
        STATUS.put("backend-ms-b", "Desconhecido");
        STATUS.put("conexao", "Desconhecido");
    }

    @GetMapping("/status")
    public Map<String, String> getStatus() {
        return STATUS;
    }

    @GetMapping("/atualizar-status")
    public Map<String, String> atualizarStatus() {
        String backendAStatus = verificarBackend("https://backend-a:8443/backend-a/status");
        String backendBStatus = verificarBackend("https://backend-b:8444/backend-b/status");

        STATUS.put("backend-ms-a", backendAStatus);
        STATUS.put("backend-ms-b", backendBStatus);

        if ("Em Execução".equals(backendAStatus) && "Em Execução".equals(backendBStatus)) {
            STATUS.put("conexao", "Conectado");
        } else {
            STATUS.put("conexao", "Erro");
        }

        return STATUS;
    }

    private String verificarBackend(String url) {
        try {
            URL backendUrl = new URL(url);
            HttpsURLConnection conn = (HttpsURLConnection) backendUrl.openConnection();
            conn.setSSLSocketFactory(getSslContext().getSocketFactory());
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(3000);
            conn.connect();

            return conn.getResponseCode() == 200 ? "Em Execução" : "Desligado";
        } catch (Exception e) {
            logger.error("❌ Erro ao verificar backend {}: {}", url, e.getMessage());
            return "Desligado";
        }
    }

    private SSLContext getSslContext() {
        try {
            String trustStorePath = System.getProperty("server.ssl.trust-store");
            String trustStorePassword = System.getProperty("server.ssl.trust-store-password");

            if (trustStorePath == null || trustStorePassword == null) {
                throw new RuntimeException("❌ TrustStore não configurado. Recusando conexões inseguras.");
            }

            KeyStore trustStore = KeyStore.getInstance("PKCS12");
            try (InputStream trustStoreStream = getClass().getClassLoader().getResourceAsStream("certs/truststore.p12")) {
                trustStore.load(trustStoreStream, trustStorePassword.toCharArray());
            }

            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(trustStore);

            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, tmf.getTrustManagers(), new SecureRandom());

            logger.info("✅ SSLContext configurado com TrustStore");
            return sslContext;

        } catch (Exception e) {
            logger.error("❌ Erro ao configurar SSLContext", e);
            throw new RuntimeException("Erro ao configurar SSLContext", e);
        }
    }
}
