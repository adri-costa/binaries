package com.appsec.projetoconjur.service_principal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe principal que inicializa a aplicação Spring Boot.
 * O Spring escaneia automaticamente todos os pacotes abaixo deste
 * para registrar componentes (@Service, @Controller, @Configuration etc.).
 */
@SpringBootApplication
public class Application {
    
    /**
     * Método main – ponto de entrada da aplicação.
     * Responsável por inicializar o contexto Spring e embutir o servidor HTTP.
     */
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
