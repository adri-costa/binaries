package com.appsec.projetoconjur.service_principal.model;

/**
 * Classe usada para receber comandos enviados pelo frontend em formato JSON.
 * Exemplo de payload:
 * {
 *   "command": "az account show"
 * }
 */

public class CommandRequest {

    // Campo que armazena o comando enviado pelo usuário
    private String command;

    // Construtor vazio necessário para deserialização (JSON -> objeto Java)
    public CommandRequest() {}

    // Construtor com argumento, útil para testes ou chamadas internas
    public CommandRequest(String command) {
        this.command = command;
    }

    // Getter padrão
    public String getCommand() {
        return command;
    }

    // Setter padrão
    public void setCommand(String command) {
        this.command = command;
    }
}
