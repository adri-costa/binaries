package com.appsec.projetoconjur.service_principal.service;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

/**
 * Serviço responsável por executar comandos no sistema operacional
 * (via bash) com as variáveis do Service Principal injetadas no ambiente.
 */
@Service
public class CommandService {

    /**
     * Executa o comando recebido como string.
     * O comando será interpretado pelo shell bash da máquina onde o app está rodando.
     * As variáveis AZURE_CLIENT_ID, AZURE_TENANT_ID e AZURE_CLIENT_SECRET
     * são inseridas no ambiente do processo antes da execução.
     *
     * @param command Comando CLI a ser executado (ex: az account show)
     * @return Saída do comando, incluindo STDOUT, STDERR e exit code
     */
    public String execute(String command) {
        StringBuilder output = new StringBuilder();
        Process process = null;

        try {
            // Loga no terminal que o comando está sendo executado
            System.out.println("▶️ Executando comando: " + command);

            // Define o comando que será executado via bash
            ProcessBuilder pb = new ProcessBuilder("bash", "-c", command);

            // Injeta as variáveis de ambiente necessárias para o Azure CLI
            pb.environment().put("AZURE_CLIENT_ID", System.getProperty("AZURE_CLIENT_ID"));
            pb.environment().put("AZURE_TENANT_ID", System.getProperty("AZURE_TENANT_ID"));
            pb.environment().put("AZURE_CLIENT_SECRET", System.getProperty("AZURE_CLIENT_SECRET"));

            // Inicia o processo
            process = pb.start();

            // Captura a saída padrão (STDOUT)
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                output.append(reader.lines().collect(Collectors.joining("\n")));
            }

            // Captura a saída de erro (STDERR), se houver
            try (BufferedReader error = new BufferedReader(
                    new InputStreamReader(process.getErrorStream()))) {
                String errors = error.lines().collect(Collectors.joining("\n"));
                if (!errors.isEmpty()) {
                    output.append("\n⚠️ STDERR:\n").append(errors);
                }
            }

            // Aguarda o processo terminar e captura o código de saída
            int exitCode = process.waitFor();
            System.out.println("✅ Comando finalizado com código: " + exitCode);
            output.append("\n\n🔚 Exit code: ").append(exitCode);

            // Adiciona as variáveis do ambiente ao log para debug
            output.append("\n\n🔎 ENV DEBUG:\n");
            output.append("AZURE_CLIENT_ID=").append(System.getenv("AZURE_CLIENT_ID")).append("\n");
            output.append("AZURE_TENANT_ID=").append(System.getenv("AZURE_TENANT_ID")).append("\n");
            output.append("AZURE_CLIENT_SECRET=").append(System.getenv("AZURE_CLIENT_SECRET")).append("\n");

        } catch (Exception e) {
            // Captura qualquer exceção ao tentar executar o comando
            output.append("❌ Erro ao executar comando: ").append(e.getMessage());
        } finally {
            if (process != null) {
                process.destroy(); // Libera recursos do processo
            }
        }

        // Retorna a saída completa do comando
        return output.toString();
    }
}
