package com.appsec.projetoconjur.service_principal.controller;

import com.appsec.projetoconjur.service_principal.config.ConjurConfig;
import com.appsec.projetoconjur.service_principal.service.CommandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/")
public class Controller {

    @Autowired
    private CommandService commandService;

    @Autowired
    private ConjurConfig conjurConfig;

    // Flags internas para controle do estado de carregamento dos secrets
    private boolean conjurLoaded = false;
    private boolean secretsLoaded = false;

    // Variáveis locais com os valores dos secrets
    private String clientId = "";
    private String tenantId = "";
    private String clientSecret = "";

    /**
     * Executa o comando recebido no corpo da requisição.
     * As variáveis do Service Principal são passadas via ProcessBuilder no CommandService.
     */
    @PostMapping("/azure/run")
    public String executarComando(@RequestBody String comando) {
        return commandService.execute(comando);
    }

    /**
     * Marca a flag conjurLoaded como verdadeira.
     * Apenas para simular carregamento de variáveis do Conjur (não faz leitura real).
     */
    @PostMapping("/conjur/load")
    public String carregarConjur() {
        conjurLoaded = true;
        return "✅ Variáveis do Conjur carregadas com sucesso.";
    }

    /**
     * Marca a flag conjurLoaded como falsa.
     * Simula a remoção das variáveis do ambiente (não limpa propriedades do sistema).
     */
    @PostMapping("/conjur/clear")
    public String limparConjur() {
        conjurLoaded = false;
        return "❌ Variáveis do Conjur removidas da aplicação.";
    }

    /**
     * Carrega os valores das variáveis do sistema (setadas por ConjurConfig)
     * e preenche os campos locais da classe.
     */
    @PostMapping("/secrets/load")
    public String loadSecrets() {
        try {
            clientId = System.getProperty("AZURE_CLIENT_ID");
            tenantId = System.getProperty("AZURE_TENANT_ID");
            clientSecret = System.getProperty("AZURE_CLIENT_SECRET");

             // Se as três estiverem presentes, considera como carregado
            if (clientId != null && tenantId != null && clientSecret != null) {
                secretsLoaded = true;
                conjurLoaded = true;
                return "✅ Secrets carregados com sucesso.";
            } else {
                return "⚠️ Secrets não encontrados.";
            }
        } catch (Exception e) {
            return "❌ Erro ao carregar secrets: " + e.getMessage();
        }
    }

    /**
     * Limpa os valores locais e as variáveis de sistema.
     * Assim, simula a remoção dos secrets da aplicação.
     */
    @PostMapping("/secrets/clear")
    public String clearSecrets() {
        secretsLoaded = false;
        conjurLoaded = false;
        clientId = "";
        tenantId = "";
        clientSecret = "";

        // Limpa também as variáveis globais do sistema
        System.clearProperty("AZURE_CLIENT_ID");
        System.clearProperty("AZURE_TENANT_ID");
        System.clearProperty("AZURE_CLIENT_SECRET");

        return "✅ Secrets limpos (simulado).";
    }

    /**
     * Exibe os valores dos secrets carregados na aplicação (armazenados em memória).
     * Usado pela interface HTML.
     */
    @GetMapping("/secrets")
    public String showSecrets() {
        if (!secretsLoaded) {
            return "⚠️ Secrets ainda não carregados.";
        }

        return String.format("""
            AZURE_CLIENT_ID: %s
            AZURE_TENANT_ID: %s
            AZURE_CLIENT_SECRET: %s
            """, clientId, tenantId, clientSecret);
    }
}
