package com.appsec.projetoconjur.service_principal.config;

import com.cyberark.conjur.api.Conjur;
import com.cyberark.conjur.api.Credentials;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

@Configuration
public class ConjurConfig {

    // Variáveis de ambiente injetadas automaticamente pelo Spring

    @Value("${CONJUR_ACCOUNT}")
    private String account;

    @Value("${CONJUR_APPLIANCE_URL}")
    private String applianceUrl;

    @Value("${CONJUR_AUTHN_LOGIN}")
    private String authnLogin;

    @Value("${CONJUR_AUTHN_API_KEY}")
    private String authnApiKey;

    private String clientId;
    private String tenantId;

    /**
     * Este método é executado na inicialização da aplicação.
     * Ele autentica no Conjur usando as credenciais e carrega os secrets.
     */
    @Bean
    public Conjur conjurClient() {
        disableSslVerification(); // ⚠️ Usado apenas em ambiente de teste (desativa validação SSL)

        try {
            System.out.println("🔐 Iniciando autenticação no Conjur...");
            Credentials credentials = new Credentials(authnLogin, authnApiKey);
            Conjur conjur = new Conjur(credentials);
            System.out.println("✅ Autenticação no Conjur concluída.");

            // Recupera os secrets usando o SDK do Conjur
            this.clientId = conjur.variables().retrieveSecret("cybr-srv-demo-conjur-service-principal/token/client-id");
            System.out.println("🔐 client-id carregado do Conjur: " + clientId);

            this.tenantId = conjur.variables().retrieveSecret("cybr-srv-demo-conjur-service-principal/token/tenant-id");
            System.out.println("🔐 tenant-id carregado do Conjur: " + tenantId);

            String clientSecret = conjur.variables().retrieveSecret("cybr-srv-demo-conjur-service-principal/token/service-principal-api-secret");
            System.out.println("🔐 client-secret carregado do Conjur (oculto)");

            // Os secrets são armazenados como propriedades do sistema para uso posterior
            System.setProperty("AZURE_CLIENT_ID", clientId);
            System.setProperty("AZURE_TENANT_ID", tenantId);
            System.setProperty("AZURE_CLIENT_SECRET", clientSecret);

            return conjur;
        } catch (Exception e) {
            throw new RuntimeException("❌ Falha ao autenticar e buscar secrets no Conjur", e);
        }
    }

    // Getters opcionais para uso em outros pontos da aplicação
    public String getClientId() {
        return clientId;
    }

    public String getTenantId() {
        return tenantId;
    }

    /**
     * Desativa verificação SSL – usado somente para fins de testes locais.
     * Em produção, esta prática não é recomendada.
     */
    private void disableSslVerification() {
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                public X509Certificate[] getAcceptedIssuers() { return null; }
            }}, new SecureRandom());

            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
        } catch (Exception e) {
            throw new RuntimeException("❌ Erro ao desativar SSL", e);
        }
    }
}
