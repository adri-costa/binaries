# 🔐 Projeto: demo-conjur-postgre

Projeto Java Spring Boot que se conecta ao **Conjur Enterprise** para buscar segredos (usuário e senha) e realizar uma conexão com um banco **PostgreSQL** externo.

---

## 📚 Índice por Perfil de Usuário

- [Desenvolvedores](#💻-para-desenvolvedores)
- [DevOps](#⚖️-para-devops)
- [Infraestrutura](#🛠️-para-infraestrutura)
- [Administradores do Conjur](#🔒-para-administradores-do-conjur)

---

## 💻 Para Desenvolvedores

### 📌 Visão Geral
Aplicação Spring Boot 3.4.2 (Java 17) que utiliza o SDK oficial do Conjur (`conjur-api 3.0.5-SNAPSHOT`) para buscar secrets e conectar a um banco PostgreSQL.

### 🔧 Integração com o SDK
A classe `ConjurConfig.java` é responsável por autenticar no Conjur e injetar os segredos como variáveis de ambiente:

```java
@Bean
public Conjur conjurClient() {
    Credentials credentials = new Credentials(authnLogin, authnApiKey);
    Conjur conjur = new Conjur(credentials);

    System.setProperty("DB_USERNAME", conjur.variables().retrieveSecret("demo-conjur-postgre/token/db-username"));
    System.setProperty("DB_PASSWORD", conjur.variables().retrieveSecret("demo-conjur-postgre/password/db-password"));

    return conjur;
}
```

> ⚠️ Em ambientes de testes, o SSL é desativado propositalmente.

### 🎯 Endpoint principal

A classe `CredentialController` expõe o endpoint `/secrets` que:
- Exibe o conteúdo dos segredos (`db-username`, `db-password`)
- Realiza uma consulta SQL usando `JdbcTemplate`

Resultado exibido em HTML direto na resposta do endpoint:

```
http://localhost:8080/secrets
```

### 📦 Dependências (pom.xml)

```xml
<dependency>
  <groupId>com.cyberark.conjur</groupId>
  <artifactId>conjur-api</artifactId>
  <version>3.0.5-SNAPSHOT</version>
</dependency>
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-jdbc</artifactId>
</dependency>
<dependency>
  <groupId>org.postgresql</groupId>
  <artifactId>postgresql</artifactId>
</dependency>
```

### 📁 Estrutura de Código

```
backend/
├── pom.xml
├── src/main/java/com/appsec/projetoconjur/backend/
│   ├── BackendApplication.java              # Classe principal
│   ├── config/ConjurConfig.java             # SDK + secrets -> env
│   └── controller/CredentialController.java # Exibe os dados no endpoint
└── src/main/resources/
    ├── application.properties
    └── templates/index.html
```

### ▶️ Como Executar

```bash
export CONJUR_ACCOUNT=projeto-conjur
export CONJUR_APPLIANCE_URL=https://proxy:30443
export CONJUR_AUTHN_LOGIN=host/demo-conjur-postgre/backend
export CONJUR_AUTHN_API_KEY=************

cd backend
mvn clean install spring-boot:run
```

---

## ⚖️ Para DevOps

### 🚚 Pipeline de Uso

1. Aplicar políticas no Conjur (ver seção Admin abaixo)
2. Definir secrets com `conjur variable set`
3. Executar a aplicação (local, Docker ou K8s)
4. Executar rotação manual se necessário

### 🔄 Roteiro de Rotação Manual

Script `rotate-db-password.sh`:
- Altera senha do PostgreSQL
- Atualiza valor no Conjur via `kubectl exec`

---

## 🛠️ Para Infraestrutura

### 🐘 PostgreSQL Setup
```bash
sudo -i -u postgres
psql
```
```sql
CREATE DATABASE projetoconjur_db;
CREATE USER backend_user WITH PASSWORD 'backend_pass';
GRANT ALL PRIVILEGES ON DATABASE projetoconjur_db TO backend_user;
```
> ⚠️ Os nomes devem coincidir com os valores no Conjur.

---

## 🔒 Para Administradores do Conjur

### 📄 Políticas

**hosts.yaml**
```yaml
- !policy
  id: demo-conjur-postgre
  body:
    - !host backend
```

**secrets.yaml**
```yaml
- !policy
  id: demo-conjur-postgre
  body:
    - !variable password/db-password
    - !variable token/db-username
```

**access.yaml**
```yaml
- !policy
  id: demo-conjur-postgre
  body:
    - !group postgre-readers
    - !grant
      role: !group postgre-readers
      member: !host backend
    - !permit
      role: !group postgre-readers
      privileges: [ read, execute ]
      resource: !variable token/db-username
    - !permit
      role: !group postgre-readers
      privileges: [ read, execute ]
      resource: !variable password/db-password
```

**auth.yaml**
```yaml
- !policy
  id: conjur/authn/projeto-conjur
  body:
    - !webservice
    - !variable enabled
    - !group authenticate
- !grant
  role: !group conjur/authn/projeto-conjur/authenticate
  member: !host demo-conjur-postgre/backend
```

### ✅ Aplicar políticas
```bash
conjur policy load --branch root --file hosts.yaml
conjur policy load --branch root --file secrets.yaml
conjur policy load --branch root --file access.yaml
conjur policy load --branch root --file auth.yaml
```

### 🔑 Definir valores dos segredos
```bash
conjur variable set -i demo-conjur-postgre/token/db-username -v backend_user
conjur variable set -i demo-conjur-postgre/password/db-password -v backend_pass
```

---

