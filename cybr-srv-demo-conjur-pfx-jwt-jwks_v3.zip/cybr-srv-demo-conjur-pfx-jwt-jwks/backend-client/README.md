# Backend Client - JWT com Certificado PFX via CyberArk Conjur

Esta aplicação Java Spring Boot gera um JWT assinado com um certificado armazenado no CyberArk Conjur, utilizando o SDK oficial (`conjur-api`) e expõe o token via endpoint HTTP.

## 🔐 Funcionalidades

- Autentica no Conjur com API Key.
- Recupera um certificado PFX (armazenado como base64) do Conjur.
- Extrai a chave privada do PFX.
- Gera um JWT assinado com essa chave.
- Expõe o JWT via endpoint `/token`.

## 🚀 Executando localmente

```bash
mvn clean package
java -jar target/backend-client-0.0.1-SNAPSHOT.jar
```

A aplicação estará disponível em [http://localhost:8081/token](http://localhost:8081/token).

## ⚙️ Variáveis de ambiente

As seguintes variáveis devem estar definidas no ambiente ou no `application.properties`:

- `CONJUR_ACCOUNT`
- `CONJUR_APPLIANCE_URL`
- `CONJUR_AUTHN_LOGIN`
- `CONJUR_AUTHN_API_KEY`

## 📦 Secret esperada no Conjur

Certificado PFX armazenado como base64 em:

```
demo-conjur-jwt/pfx/backend-client
```

## 🧪 Endpoint

- `GET /token`: retorna o JWT assinado.

## 🛠️ Requisitos

- Java 17
- Maven
- Conjur CLI (para testes)
- CyberArk Conjur Enterprise com variável de secret configurada

---

© Projeto de laboratório para testes com JWT, PFX e JWKs.