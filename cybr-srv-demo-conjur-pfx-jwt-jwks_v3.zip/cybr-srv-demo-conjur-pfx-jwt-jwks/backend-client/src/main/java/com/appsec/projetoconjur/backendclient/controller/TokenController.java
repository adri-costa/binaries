package com.appsec.projetoconjur.backendclient.controller;

import com.cyberark.conjur.api.Conjur;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.StringReader;
import java.security.PrivateKey;
import java.security.Security;
import java.util.Date;

/**
 * Esta classe expõe endpoints para geração de JWT assinado com chave privada
 * armazenada no Conjur. O JWT é assinado com RS256 e contém claims básicos.
 */
@RestController
public class TokenController {

    @Autowired
    private Conjur conjur;

    /**
     * Endpoint que gera JWT usando o segredo 'jwt-signing-cert'
     */
    @GetMapping("/token/1")
    public String gerarJwt1() {
        return gerarJwt("secrets-app/jwt-signing-cert");
    }

    /**
     * Endpoint que gera JWT usando o segredo 'jwt-signing-cert-2'
     */
    @GetMapping("/token/2")
    public String gerarJwt2() {
        return gerarJwt("secrets-app/jwt-signing-cert-2");
    }

    /**
     * Endpoint que gera JWT usando o segredo 'jwt-signing-cert-3'
     */
    @GetMapping("/token/3")
    public String gerarJwt3() {
        return gerarJwt("secrets-app/jwt-signing-cert-3");
    }

    /**
     * Função utilitária para gerar um JWT com base na variável do Conjur
     */
    private String gerarJwt(String pemVar) {
        try {
            // Recupera a chave privada (em PEM) do Conjur
            String pemContent = conjur.variables().retrieveSecret(pemVar);

            // Extrai a chave privada do conteúdo PEM
            PrivateKey privateKey = extractPrivateKey(pemContent);

            // Constrói os claims do token
            JWTClaimsSet claims = new JWTClaimsSet.Builder()
                    .issuer("backend-client")
                    .subject("jwt-gerado")
                    .audience("backend-server")
                    .issueTime(new Date())
                    .expirationTime(new Date(System.currentTimeMillis() + 10 * 60 * 1000)) // 10 min
                    .claim("scope", "acesso-api")
                    .build();

            // Cabeçalho do JWT (com KID)
            JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.RS256)
                    .type(JOSEObjectType.JWT)
                    .keyID(getKidFromVar(pemVar))
                    .build();

            // Cria e assina o JWT
            SignedJWT signedJWT = new SignedJWT(header, claims);
            signedJWT.sign(new RSASSASigner(privateKey));

            return signedJWT.serialize();

        } catch (Exception e) {
            return "Erro ao gerar JWT: ❌ " + e.getMessage();
        }
    }

    /**
     * Gera o valor de "kid" com base no sufixo da variável
     */
    private String getKidFromVar(String varName) {
        if (varName.endsWith("-2")) return "2";
        if (varName.endsWith("-3")) return "3";
        return "1";
    }

    /**
     * Converte o conteúdo PEM em PrivateKey usando BouncyCastle
     */
    private PrivateKey extractPrivateKey(String pemContent) throws Exception {
        Security.addProvider(new BouncyCastleProvider());

        try (PEMParser pemParser = new PEMParser(new StringReader(pemContent))) {
            Object object = pemParser.readObject();

            if (object instanceof PEMKeyPair) {
                return new JcaPEMKeyConverter()
                        .setProvider("BC")
                        .getKeyPair((PEMKeyPair) object)
                        .getPrivate();
            } else if (object instanceof PrivateKeyInfo) {
                return new JcaPEMKeyConverter()
                        .setProvider("BC")
                        .getPrivateKey((PrivateKeyInfo) object);
            } else {
                throw new IllegalArgumentException("❌ Bloco PEM inválido ou incompleto.");
            }
        }
    }
}
