package com.appsec.projetoconjur.backendclient.config;

import com.cyberark.conjur.api.Conjur;
import com.cyberark.conjur.api.Credentials;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.*;
import java.io.ByteArrayInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Base64;

@Configuration
public class ConjurConfig {

    @Value("${CONJUR_ACCOUNT}")
    private String account;

    @Value("${CONJUR_APPLIANCE_URL}")
    private String applianceUrl;

    @Value("${CONJUR_AUTHN_LOGIN}")
    private String authnLogin;

    @Value("${CONJUR_AUTHN_API_KEY}")
    private String authnApiKey;

    @Bean
    public Conjur conjurClient() {
        disableSslVerification();
        Credentials credentials = new Credentials(authnLogin, authnApiKey);

        Conjur conjur = new Conjur(credentials);
        // 🔍 Exibe o conteúdo da variável jwt-signing-cert para depuração
        try {
            String pem = conjur.variables().retrieveSecret("secrets-app/jwt-signing-cert");
            System.out.println("🔐 Conteúdo recebido de 'jwt-signing-cert':\n" + pem);
        } catch (Exception e) {
            System.err.println("❌ Erro ao recuperar 'jwt-signing-cert': " + e.getMessage());
        }

        return conjur;
    }

    private void disableSslVerification() {
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{ new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                public X509Certificate[] getAcceptedIssuers() { return null; }
            } }, new SecureRandom());

            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);

        } catch (Exception e) {
            System.err.println("Erro ao configurar certificado e chave privada:");
            e.printStackTrace(); // <-- imprime no terminal
            throw new RuntimeException("Erro ao configurar certificado e chave privada", e);
        }
    }
    
}
