from cryptography.hazmat.primitives import serialization
from jose.utils import base64url_encode
import json
import sys
import os

key_path = sys.argv[1]
with open(key_path, "rb") as f:
    private_key = serialization.load_pem_private_key(f.read(), password=None)

public_key = private_key.public_key()
numbers = public_key.public_numbers()

e = base64url_encode(numbers.e.to_bytes(3, 'big')).decode()
n = base64url_encode(numbers.n.to_bytes((numbers.n.bit_length() + 7) // 8, 'big')).decode()

filename = os.path.basename(key_path).replace("client", "backend-client").replace(".key", "-key")

jwk = {
    "kty": "RSA",
    "use": "sig",
    "alg": "RS256",
    "kid": filename,
    "n": n,
    "e": e
}

print(json.dumps(jwk, indent=2))
