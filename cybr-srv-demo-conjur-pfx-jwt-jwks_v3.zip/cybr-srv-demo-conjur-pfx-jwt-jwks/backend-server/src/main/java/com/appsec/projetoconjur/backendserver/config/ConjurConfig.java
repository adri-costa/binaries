package com.appsec.projetoconjur.backendserver.config;

import com.cyberark.conjur.api.Conjur;
import com.cyberark.conjur.api.Credentials;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

/**
 * Classe responsável pela configuração do cliente Conjur.
 * Faz a autenticação usando as variáveis de ambiente injetadas pelo sidecar
 * e desativa a verificação SSL (uso exclusivo para ambientes de teste).
 */
@Configuration
public class ConjurConfig {

    @Value("${CONJUR_ACCOUNT}")
    private String account;

    @Value("${CONJUR_APPLIANCE_URL}")
    private String applianceUrl;

    @Value("${CONJUR_AUTHN_LOGIN}")
    private String authnLogin;

    @Value("${CONJUR_AUTHN_API_KEY}")
    private String authnApiKey;

    /**
     * Cria e autentica o cliente do Conjur usando o SDK oficial.
     */
    @Bean
    public Conjur conjurClient() {
        disableSslVerification(); // ⚠️ Desativa SSL para testes

        System.out.println("🔎 DEBUG: Variáveis visíveis pelo SDK:");
        System.out.println("CONJUR_ACCOUNT: " + System.getenv("CONJUR_ACCOUNT"));
        System.out.println("CONJUR_APPLIANCE_URL: " + System.getenv("CONJUR_APPLIANCE_URL"));
        System.out.println("CONJUR_AUTHN_LOGIN: " + System.getenv("CONJUR_AUTHN_LOGIN"));
        System.out.println("CONJUR_AUTHN_API_KEY: " + System.getenv("CONJUR_AUTHN_API_KEY"));

        try {
            Credentials credentials = new Credentials(authnLogin, authnApiKey);
            return new Conjur(credentials);
        } catch (Exception e) {
            throw new RuntimeException("❌ Falha na conexão com o Conjur", e);
        }
    }

    /**
     * ⚠️ Desabilita a verificação SSL. Apenas para ambiente de testes com certificados self-signed.
     */
    private void disableSslVerification() {
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{ new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                public X509Certificate[] getAcceptedIssuers() { return null; }
            } }, new SecureRandom());

            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
        } catch (Exception e) {
            throw new RuntimeException("❌ Erro ao desativar SSL", e);
        }
    }
}
