package com.appsec.projetoconjur.backendserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe principal da aplicação Spring Boot.
 * Ao executar, inicia o contexto Spring e publica os endpoints REST.
 */
@SpringBootApplication
public class BackendApplication {

    public static void main(String[] args) {
        // Inicia a aplicação Spring Boot
        SpringApplication.run(BackendApplication.class, args);
    }
}
