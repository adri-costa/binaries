package com.appsec.projetoconjur.backendserver.controller;

import com.cyberark.conjur.api.Conjur;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

/**
 * Controlador responsável por validar JWTs recebidos via header Authorization,
 * com suporte a múltiplos conjuntos de chaves e fallback para chave anterior.
 */
@RestController
@RequestMapping("/validate")
public class JwtValidationController {

    @Autowired
    private Conjur conjur;

    // Mapeia o valor de 'kid' para a variável atual no Conjur
    private final Map<String, String> kidToVarAtual = new HashMap<>();

    // Mapeia o valor de 'kid' para a variável -previous no Conjur (para fallback)
    private final Map<String, String> kidToVarAnterior = new HashMap<>();

    /**
     * Inicializa os mapeamentos entre 'kid' e as variáveis no Conjur
     * (atual e anterior), utilizados na validação do JWT.
     */
    @jakarta.annotation.PostConstruct
    public void init() {
        kidToVarAtual.put("1", "secrets-app/jwt-verification-jwk");
        kidToVarAtual.put("2", "secrets-app/jwt-verification-jwk-2");
        kidToVarAtual.put("3", "secrets-app/jwt-verification-jwk-3");

        kidToVarAnterior.put("1", "secrets-app/jwt-verification-jwk-previous");
        kidToVarAnterior.put("2", "secrets-app/jwt-verification-jwk-2-previous");
        kidToVarAnterior.put("3", "secrets-app/jwt-verification-jwk-3-previous");

        System.out.println("✅ Mapeamentos de JWK atual e anterior carregados");
    }

    /**
     * Endpoint que valida um JWT enviado via header Authorization: Bearer <token>.
     * O JWT deve conter o campo 'kid' no header, indicando qual chave usar.
     * A validação tenta primeiro a chave atual e, se falhar, tenta a chave anterior.
     */
    @GetMapping
    public ResponseEntity<String> validateJwt(HttpServletRequest request) {
        try {
            // Recupera o header Authorization
            String authHeader = request.getHeader("Authorization");

            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Missing Authorization header");
            }

            // Extrai o token JWT
            String token = authHeader.substring(7);
            JWSObject jwsObject = JWSObject.parse(token);

            // Lê o header do JWT para obter o 'kid'
            JWSHeader header = jwsObject.getHeader();
            String kid = header.getKeyID();

            if (kid == null || !kidToVarAtual.containsKey(kid)) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Kid não reconhecido: " + kid);
            }

            // Tenta verificar o JWT com a chave atual
            if (verificarAssinatura(jwsObject, kidToVarAtual.get(kid))) {
                return ResponseEntity.ok("JWT válido (kid=" + kid + ")");
            }

            // Se falhar, tenta com a chave anterior
            if (verificarAssinatura(jwsObject, kidToVarAnterior.get(kid))) {
                return ResponseEntity.ok("JWT válido com chave anterior (kid=" + kid + ")");
            }

            // Se nenhuma das assinaturas for válida
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("JWT inválido (kid=" + kid + ")");

        } catch (ParseException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Erro ao processar JWT: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro interno: " + e.getMessage());
        }
    }

    /**
     * Tenta verificar a assinatura do JWT usando a chave pública
     * armazenada na variável do Conjur informada.
     *
     * @param jwsObject JWT já decodificado
     * @param conjurVar Nome da variável no Conjur que contém o JWK
     * @return true se a assinatura for válida; false caso contrário
     */
    private boolean verificarAssinatura(JWSObject jwsObject, String conjurVar) {
        try {
            // Recupera o JWK no formato JSON armazenado no Conjur
            String jwkJson = conjur.variables().retrieveSecret(conjurVar);

            // Converte o JSON para objeto JWK
            JWK jwk = JWKSet.parse("{\"keys\":[" + jwkJson + "]}").getKeys().get(0);

            // Verifica a assinatura usando a chave pública
            RSASSAVerifier verifier = new RSASSAVerifier(jwk.toRSAKey().toRSAPublicKey());
            return jwsObject.verify(verifier);

        } catch (Exception e) {
            // Qualquer erro (parse, ausência da variável, etc.) será tratado como falha na assinatura
            return false;
        }
    }
}
