# 🔐 Projeto: cybr-srv-demo-conjur-pfx-jwt-jwks

Aplicação Java Spring Boot que valida JWTs assinados com chave privada armazenada no **Conjur Enterprise**. A chave pública no formato **JWK** também é carregada a partir do Conjur para validação dos tokens.

---

## 💻 Para Desenvolvedores

### ✅ Funcionalidade principal

- A aplicação expõe o endpoint `/validate`.
- O JWT deve ser enviado no header `Authorization: Bearer <token>`.
- Se o token for válido → `HTTP 200 OK`
- Se o token for inválido → `HTTP 401 Unauthorized`

### 🛠️ Estrutura de Código

```
backend-server/
├── pom.xml
├── src/main/java/com/appsec/projetoconjur/backendserver/
│   ├── Application.java                 # Classe principal
│   ├── config/ConjurConfig.java         # Carrega os secrets do Conjur
│   └── controller/JwtValidationController.java  # Endpoint /validate
└── src/main/resources/
    └── application.properties           # Configurações do Conjur
```

### 🔐 Secrets esperadas no Conjur

A aplicação espera que os seguintes segredos estejam definidos no Conjur:

| Nome da variável no Conjur              | Uso                                 |
|----------------------------------------|--------------------------------------|
| `secrets-app/jwt-verification-jwk`     | JWK com a chave pública (base64)     |
| `secrets-app/jwt-signing-cert`         | Certificado PFX (base64)             |
| `secrets-app/jwt-signing-cert-password`| Senha do PFX                         |

As variáveis devem ser entregues por **sidecar**, já disponíveis no ambiente.

### ▶️ Como Executar (Exemplo com Maven)

```bash
# Exemplo de execução local (após sidecar rodar e injetar variáveis)
mvn clean spring-boot:run
```

---

## ⚙️ Para DevOps

- O container escuta na porta `8080`
- Use Kubernetes com Sidecar do Conjur para entregar variáveis de ambiente
- Não há interface web, apenas o endpoint `/validate`

### ✅ Teste rápido com curl

```bash
curl -i -H "Authorization: Bearer <jwt>" http://localhost:8080/validate
```

---

## 🔒 Para Administradores do Conjur

- Use `conjur variable set` para definir os valores:
```bash
conjur variable set -i secrets-app/jwt-verification-jwk -v '<conteúdo JWK>'
conjur variable set -i secrets-app/jwt-signing-cert -v '<certificado PFX base64>'
conjur variable set -i secrets-app/jwt-signing-cert-password -v 'MinhaSenha123'
```

- Use políticas para definir hosts e permissões conforme necessário.

---

© CyberArk Conjur Lab - JWT + PFX + JWK Demo