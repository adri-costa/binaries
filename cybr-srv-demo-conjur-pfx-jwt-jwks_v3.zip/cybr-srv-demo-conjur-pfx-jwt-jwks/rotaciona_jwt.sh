#!/bin/bash

set -e

DIR="/opt/conjur/conjur-quickstart/certs"
CA_KEY="$DIR/ca.key"
CA_CRT="$DIR/ca.crt"
JWK_GEN="/opt/conjur/conjur-quickstart/generate_jwk.py"

echo "Qual conjunto deseja rotacionar? (1, 2 ou 3): "
read -r SET

if [[ ! "$SET" =~ ^[123]$ ]]; then
  echo "Entrada inválida. Use 1, 2 ou 3."
  exit 1
fi

SUFFIX=""
[[ "$SET" != "1" ]] && SUFFIX="-$SET"

KEY="$DIR/client$SUFFIX.key"
CSR="$DIR/client$SUFFIX.csr"
CRT="$DIR/client$SUFFIX.crt"
PEM="$DIR/client$SUFFIX.pem"
JWK="$DIR/backend-client$SUFFIX.jwk"

# Backup dos valores atuais
CERT=$(sudo docker compose exec client conjur variable get -i secrets-app/jwt-signing-cert$SUFFIX)
PASS=$(sudo docker compose exec client conjur variable get -i secrets-app/jwt-signing-cert-password$SUFFIX)
JWK_VAL=$(sudo docker compose exec client conjur variable get -i secrets-app/jwt-verification-jwk$SUFFIX)

sudo docker compose exec client conjur variable set -i secrets-app/jwt-signing-cert$SUFFIX-previous -v "$CERT"
sudo docker compose exec client conjur variable set -i secrets-app/jwt-signing-cert-password$SUFFIX-previous -v "$PASS"
sudo docker compose exec client conjur variable set -i secrets-app/jwt-verification-jwk$SUFFIX-previous -v "$JWK_VAL"

# Gera nova chave privada
openssl genrsa -out "$KEY" 2048

# Gera CSR
openssl req -new -key "$KEY" -subj "/CN=backend-client" -out "$CSR"

# Assina com a CA
openssl x509 -req -in "$CSR" -CA "$CA_CRT" -CAkey "$CA_KEY" -CAcreateserial -out "$CRT" -days 365 -sha256

# Gera senha aleatória
PASSWORD=$(tr -dc A-Za-z0-9 </dev/urandom | head -c 10)

# Gera PEM concatenado
cat "$KEY" "$CRT" > "$PEM"

# Gera JWK
python3 "$JWK_GEN" "$KEY" > "$JWK"

# Popula no Conjur com os novos valores
sudo docker compose exec -T client conjur variable set -i secrets-app/jwt-signing-cert$SUFFIX -v "$(cat "$PEM")"
sudo docker compose exec client conjur variable set -i secrets-app/jwt-signing-cert-password$SUFFIX -v "$PASSWORD"
sudo docker compose exec client conjur variable set -i secrets-app/jwt-verification-jwk$SUFFIX -v "$(cat "$JWK" | jq -c .)"

# Limpa arquivos temporários
rm -f "$CSR"

echo "Conjunto$SUFFIX rotacionado com sucesso."
