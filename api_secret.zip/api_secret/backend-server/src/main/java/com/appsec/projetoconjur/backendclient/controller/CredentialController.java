package com.appsec.projetoconjur.backendserver.controller;

import com.cyberark.conjur.api.Conjur;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.logging.Logger;

@RestController
@RequestMapping("/status")
public class CredentialController {

    @Autowired
    private Conjur conjur;

    private final Logger logger = Logger.getLogger(CredentialController.class.getName());
    private final String secretPath = "demo-conjur-api-secret/token/backend-client-api-secret";

    @GetMapping
    public ResponseEntity<String> status(@RequestHeader(value = "X-API-SECRET", required = false) String apiSecret) {
        try {
            logger.info("📥 Requisição recebida no /status com header X-API-SECRET: " + (apiSecret != null ? maskSecret(apiSecret) : "NULO"));

            if (apiSecret == null) {
                logger.info("🔒 Requisição recebida sem secret. Acesso restrito.");
                return ResponseEntity.ok("🔒 Informar API Secret");
            }

            String secretReal = conjur.variables().retrieveSecret(secretPath);

            if (apiSecret.equals(secretReal)) {
                logger.info("✅ Secret válido — acesso concedido");
                return ResponseEntity.ok("✅ Secret válido — sucesso!");
            } else {
                logger.warning("🔐 Secret inválido recebido.");
                return ResponseEntity.ok("🔐 Token inválido");
            }
        } catch (Exception e) {
            logger.severe("❌ Erro ao acessar o Conjur: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro no servidor");
        }
    }

    private String maskSecret(String secret) {
        if (secret == null || secret.length() <= 6) {
            return "******";
        }
        int middleLength = secret.length() - 6;
        return secret.substring(0, 3) + "*".repeat(middleLength) + secret.substring(secret.length() - 3);
    }
}
