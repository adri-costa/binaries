package com.appsec.projetoconjur.backendserver.config;

import com.cyberark.conjur.api.Conjur;
import com.cyberark.conjur.api.Credentials;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

@Configuration
public class ConjurConfig {

    @Value("${CONJUR_ACCOUNT}")
    private String account;

    @Value("${CONJUR_APPLIANCE_URL}")
    private String applianceUrl;

    @Value("${CONJUR_AUTHN_LOGIN}")
    private String authnLogin;

    @Value("${CONJUR_AUTHN_API_KEY}")
    private String authnApiKey;

    private void disableSslVerification() {
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                public X509Certificate[] getAcceptedIssuers() { return null; }
            }}, new SecureRandom());

            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
        } catch (Exception e) {
            throw new RuntimeException("❌ Erro ao desativar verificação SSL", e);
        }
    }

    @Bean
    public Conjur conjurClient() {
        disableSslVerification();

        System.out.println("🔎 DEBUG: Conectando ao Conjur:");
        System.out.println("CONJUR_ACCOUNT: " + account);
        System.out.println("CONJUR_APPLIANCE_URL: " + applianceUrl);
        System.out.println("CONJUR_AUTHN_LOGIN: " + authnLogin);
        System.out.println("CONJUR_AUTHN_API_KEY: " + authnApiKey);

        try {
            Credentials credentials = new Credentials(authnLogin, authnApiKey);
            return new Conjur(credentials);
        } catch (Exception e) {
            throw new RuntimeException("❌ Falha ao conectar ao Conjur", e);
        }
    }
}
