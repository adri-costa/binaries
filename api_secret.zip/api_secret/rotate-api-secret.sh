#!/bin/bash

# ===============================================
# 🔄 Script de Rotação do Secret no Conjur (CLI)
# ===============================================

# Caminho do segredo no Conjur
CONJUR_VAR="demo-conjur-api-secret/token/backend-client-api-secret"

# Gera novo valor secreto aleatório (sem caracteres problemáticos)
NEW_SECRET=$(openssl rand -base64 24 | tr -d '=+/')

# Exibe parte do secret no terminal (sem vazar)
echo "🔐 Novo secret gerado: ${NEW_SECRET:0:3}********${NEW_SECRET: -3}"

# Verifica se o comando conjur está disponível
if ! command -v conjur &> /dev/null; then
  echo "⚠️ CLI do Conjur não encontrado. Tentando via kubectl exec no pod..."

  # Captura automática do nome do pod master
  POD_NAME=$(kubectl get pods -n conjur -l app=conjur-master -o jsonpath="{.items[0].metadata.name}")

  if [ -z "$POD_NAME" ]; then
    echo "❌ Nenhum pod conjur-master encontrado no namespace 'conjur'."
    exit 1
  fi

  echo "📦 Executando dentro do pod: $POD_NAME"
  kubectl exec -n conjur "$POD_NAME" -- \
    conjur variable set --id "$CONJUR_VAR" --value "$NEW_SECRET"

  if [ $? -eq 0 ]; then
    echo "✅ Secret atualizado com sucesso via kubectl!"
  else
    echo "❌ Falha ao atualizar o secret no Conjur via pod."
    exit 1
  fi

else
  echo "📤 Atualizando valor no Conjur via CLI local..."
  conjur variable set --id "$CONJUR_VAR" --value "$NEW_SECRET"

  if [ $? -eq 0 ]; then
    echo "✅ Secret atualizado com sucesso via conjur CLI!"
  else
    echo "❌ Falha ao atualizar o secret no Conjur via CLI."
    exit 1
  fi
fi

# Registro de auditoria local
LOG_FILE="rotation-log.txt"
echo "$(date '+%Y-%m-%d %H:%M:%S') - Secret rotacionado com sucesso - ID: $CONJUR_VAR" >> "$LOG_FILE"
tail -5 "$LOG_FILE"
