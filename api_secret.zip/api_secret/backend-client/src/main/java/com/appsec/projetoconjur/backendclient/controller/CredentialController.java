package com.appsec.projetoconjur.backendclient.controller;

import com.cyberark.conjur.api.Conjur;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.logging.Logger;

@RestController
@RequestMapping
public class CredentialController {

    @Autowired
    private Conjur conjur;

    private final Logger logger = Logger.getLogger(CredentialController.class.getName());

    private final String secretPath = "demo-conjur-api-secret/token/backend-client-api-secret";
    private final String backendServerUrl = "http://localhost:8081/status";

    @GetMapping("/valida-status")
    public ResponseEntity<String> validarStatus(@RequestParam(defaultValue = "false") boolean sendSecret) {
        try {
            RestTemplate restTemplate = new RestTemplate();
            HttpHeaders headers = new HttpHeaders();

            if (sendSecret) {
                logger.info("🔐 Enviando secret para o backend-server...");
                String secret = conjur.variables().retrieveSecret(secretPath);
                headers.set("X-API-SECRET", secret);
            } else {
                logger.info("🔍 Requisição simples sem secret...");
            }

            logger.info("➡️ Enviando requisição para: " + backendServerUrl);
            logger.info("➡️ Headers: " + headers.toString());

            HttpEntity<String> requestEntity = new HttpEntity<>(headers);
            ResponseEntity<String> response = restTemplate.exchange(
                    backendServerUrl,
                    HttpMethod.GET,
                    requestEntity,
                    String.class
            );

            logger.info("⬅️ Resposta recebida: " + response);
            return ResponseEntity.ok(response.getBody());

        } catch (RestClientException e) {
            logger.severe("🚫 Erro ao conectar com backend-server: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                    .body("⚠️ Backend-server está indisponível ou recusando conexão.");
        } catch (Exception e) {
            logger.severe("❌ Erro inesperado: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("❌ Erro interno ao processar requisição.");
        }
    }

    @GetMapping("/secret")
    public ResponseEntity<String> getSecret() {
        try {
            String secret = conjur.variables().retrieveSecret(secretPath);
            String maskedSecret = maskSecret(secret);
            logger.info("🔐 Secret acessado e mascarado: " + maskedSecret);
            return ResponseEntity.ok("🔐 " + maskedSecret);
        } catch (Exception e) {
            logger.warning("⚠️ Secret não encontrado ou não acessível: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("⚠️ O secret ainda não está disponível no Conjur.");
        }
    }

    private String maskSecret(String secret) {
        if (secret == null || secret.length() <= 6) {
            return "******";
        }
        int middleLength = secret.length() - 6;
        return secret.substring(0, 3) + "*".repeat(middleLength) + secret.substring(secret.length() - 3);
    }
}
