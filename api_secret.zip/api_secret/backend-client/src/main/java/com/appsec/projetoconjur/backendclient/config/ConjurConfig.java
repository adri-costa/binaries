package com.appsec.projetoconjur.backendclient.config;

import com.cyberark.conjur.api.Conjur;
import com.cyberark.conjur.api.Credentials;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

@Configuration
public class ConjurConfig {

    @Value("${CONJUR_ACCOUNT}")
    private String account;

    @Value("${CONJUR_APPLIANCE_URL}")
    private String applianceUrl;

    @Value("${CONJUR_AUTHN_LOGIN}")
    private String authnLogin;

    @Value("${CONJUR_AUTHN_API_KEY}")
    private String authnApiKey;

    /**
     * Desabilita a verificação SSL (laboratório / autoassinado).
     */
    private void disableSslVerification() {
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                public X509Certificate[] getAcceptedIssuers() { return null; }
            }}, new SecureRandom());

            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
        } catch (Exception e) {
            throw new RuntimeException("❌ Erro ao desativar verificação SSL", e);
        }
    }

    /**
     * Cria o bean Conjur e injeta o segredo como variável de sistema.
     */
    @Bean
    public Conjur conjurClient() {
        disableSslVerification();

        // 🔎 Log das variáveis usadas na autenticação
        System.out.println("🔎 DEBUG: Variáveis visíveis pelo SDK:");
        System.out.println("CONJUR_ACCOUNT: " + account);
        System.out.println("CONJUR_APPLIANCE_URL: " + applianceUrl);
        System.out.println("CONJUR_AUTHN_LOGIN: " + authnLogin);
        System.out.println("CONJUR_AUTHN_API_KEY: " + authnApiKey);

        try {
            // 🔐 Cria o objeto de autenticação com login e API key
            Credentials credentials = new Credentials(authnLogin, authnApiKey);
            Conjur conjur = new Conjur(credentials);

            // 🔐 Busca o segredo do Conjur e injeta no ambiente
            String apiSecret = conjur.variables().retrieveSecret("demo-conjur-api-secret/token/backend-client-api-secret");
            System.setProperty("API_CLIENT_SECRET", apiSecret);

            System.out.println("✅ API_CLIENT_SECRET injetado no ambiente.");
            return conjur;
        } catch (Exception e) {
            throw new RuntimeException("❌ Falha na conexão com o Conjur", e);
        }
    }
}
