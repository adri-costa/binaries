# 🔐 Projeto: demo-case-api-secret

Este projeto demonstra como utilizar o **CyberArk Conjur Enterprise** como gerenciador de segredos para comunicação segura entre microsserviços.  
O foco é a **injeção e validação de um segredo (API Secret)** obtido do Conjur no backend-client e validado no backend-server.

---

## 📁 Estrutura do Projeto

```
api_secret/
├── README.md
├── backend-client/
│   ├── pom.xml
│   ├── README.md
│   └── src/
│       └── main/
│           ├── java/com/appsec/projetoconjur/backendclient/
│           │   ├── BackendClientApplication.java
│           │   ├── config/ConjurConfig.java
│           │   └── controller/CredentialController.java
│           └── resources/
│               ├── application.properties
│               └── static/index.html
├── backend-server/
│   ├── pom.xml
│   ├── README.md
│   └── src/
│       └── main/
│           ├── java/com/appsec/projetoconjur/backendclient/
│           │   ├── BackendServerApplication.java
│           │   ├── config/ConjurConfig.java
│           │   └── controller/CredentialController.java
│           └── resources/
│               └── application.properties
```
---

## ☁️ Tecnologias Utilizadas

- Java 17
- Spring Boot 3.4.2
- CyberArk Conjur Enterprise 13.4.0
- Conjur Java SDK (`conjur-api 3.0.5-SNAPSHOT`)

---

## 🔧 Funcionalidade

### backend-client

- Autentica no Conjur com **API Key**
- Obtém o segredo:  
  `demo-conjur-api-secret/token/backend-client-api-secret`
- Injeta o segredo como `System.setProperty("API_CLIENT_SECRET")`
- Permite:
  - Chamada ao backend-server sem segredo
  - Chamada ao backend-server com segredo via header `X-API-SECRET`
- Interface Web (localhost:8080) com botões de teste

### backend-server

- Expõe o endpoint `/status`
- Recebe requisição com ou sem header `X-API-SECRET`
- Valida o valor do header comparando com o valor real do Conjur
- Loga o resultado no terminal:
  - 🔐 Secret válido
  - ⚠️ Secret inválido
  - ⚙️ Nenhum secret enviado

---

## 🛡️ Políticas do Conjur

As seguintes políticas foram aplicadas:

- **Identidades** (`api-secret-host-policy.yaml`)
- **Secrets** (`api-secret-secrets-policy.yaml`)
- **Acessos** (`api-secret-access-policy.yaml`)
- **Autenticação** (`auth.yaml`)

**Variável utilizada no Conjur:**

```
demo-conjur-api-secret/token/backend-client-api-secret
```

**Hosts:**

- `demo-conjur-api-secret/backend-client`
- `demo-conjur-api-secret/backend-server`


---

As políticas abaixo definem os hosts, variáveis secretas, autenticação e permissões de acesso para o projeto `demo-conjur-api-secret`.

---

### 🔐 `hosts.yaml`

```yaml
- !policy
  id: demo-conjur-api-secret
  body:
    - !host backend-client
    - !host backend-server
```

---

### 🔐 `secrets.yaml`

```yaml
- !policy
  id: demo-conjur-api-secret
  body:
    - !variable token/backend-client-api-secret
```

---

### 🔐 `access.yaml`

```yaml
- !policy
  id: demo-conjur-api-secret
  body:
    - !group api-secret-readers
    - !group api-secret-updaters
    - !group api-secret-rotators
    - !group api-secret-owners
    - !group api-secret-iam

    # Hosts autorizados
    - !grant
      role: !group api-secret-readers
      member: !host backend-client

    - !grant
      role: !group api-secret-readers
      member: !host backend-server

    # Permissões da variável
    - !permit
      role: !group api-secret-readers
      privileges: [ read, execute ]
      resource: !variable token/backend-client-api-secret

    - !permit
      role: !group api-secret-updaters
      privileges: [ update ]
      resource: !variable token/backend-client-api-secret

    - !permit
      role: !group api-secret-rotators
      privileges: [ update ]
      resource: !variable token/backend-client-api-secret
```

---

### 🔐 `auth.yaml`

```yaml
- !policy
  id: conjur/authn/projeto-conjur
  body:
    - !webservice
    - !variable enabled
    - !group authenticate

- !grant
  role: !group conjur/authn/projeto-conjur/authenticate
  member: !host demo-conjur-api-secret/backend-client

- !grant
  role: !group conjur/authn/projeto-conjur/authenticate
  member: !host demo-conjur-api-secret/backend-server
```

---

### ✅ Ordem recomendada para aplicar as políticas

```bash
conjur policy load --branch root --file hosts.yaml
conjur policy load --branch root --file secrets.yaml
conjur policy load --branch root --file access.yaml
conjur policy load --branch root --file auth.yaml
```

> 💡 Após aplicar, defina o valor do segredo com:
> ```bash
> conjur variable set -i demo-conjur-api-secret/token/backend-client-api-secret -v "valor-do-token"
> ```

---

## ▶️ Execução Local

### 1. Configurar variáveis de ambiente:

```bash
export CONJUR_ACCOUNT=projeto-conjur
export CONJUR_APPLIANCE_URL=https://proxy:30443
export CONJUR_AUTHN_LOGIN=host/demo-conjur-api-secret/backend-client
#export CONJUR_AUTHN_LOGIN=host/demo-conjur-api-secret/backend-server
export CONJUR_AUTHN_API_KEY=<API_KEY_DO_CLIENT>
```

### 2. Executar o backend-server

```bash
cd backend-server
mvn clean spring-boot:run
```

### 3. Executar o backend-client

```bash
cd backend-client
mvn clean spring-boot:run
```

---

## 🌐 Acessar o Frontend

Abra no navegador:

```
http://localhost:8080
```

Você verá:

- Botão **Validar status sem segredo**
- Botão **Validar status com segredo**
- Resultado das respostas visível ao lado dos botões

---

## 🧪 Teste de Comunicação

1. Inicie o `backend-server`
2. Acesse a interface do `backend-client`
3. Clique nos botões para testar comunicação com ou sem secret

---

## 💬 Logs esperados no backend-server

- Requisição sem header:
  ```
  ℹ️ Nenhum secret recebido
  ```

- Requisição com header inválido:
  ```
  ❌ Secret inválido recebido
  ```

- Requisição com secret correto:
  ```
  ✅ Secret válido! Comunicação autenticada.
  ```

---
