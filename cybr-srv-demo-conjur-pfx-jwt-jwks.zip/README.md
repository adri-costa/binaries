# 🔐 Aplicação Unificada: JWT com Conjur (PFX + JWK)

Aplicação Java Spring Boot que gera e valida tokens JWT usando certificados armazenados no **CyberArk Conjur**. Combina as funcionalidades de geração (PFX) e validação (JWK) em um único backend com interface web integrada.

---

## 📌 Funcionalidades

- Gera JWT com chave privada (PEM) recuperada do Conjur
- Valida JWT com chave pública (JWK) recuperada do Conjur
- Interface web para geração e validação interativa
- Utiliza apenas o conjunto atual e anterior (KID = "1")

---

## 📁 Estrutura do Projeto

```
src/
├── main/
│   ├── java/com/appsec/projetoconjur/backendserver/cybr/srv/demo/conjur/pfxjwtjwks/
│   │   ├── Application.java
│   │   ├── config/ConjurConfig.java
│   │   └── controller/
│   │       ├── TokenController.java
│   │       └── JwtValidationController.java
│   └── resources/
│       ├── application.properties
│       └── static/index.html
└── test/
    ├── controller/ (testes unitários)
    └── integration/ (testes de integração)
```

---

## 🖥️ Endpoints

| Método | Endpoint   | Descrição                       |
|--------|------------|----------------------------------|
| GET    | `/token`   | Gera um JWT assinado (KID = 1)  |
| GET    | `/validate`| Valida JWT enviado via header   |

---

## ⚙️ Execução Local

```bash
# Build local
mvn clean install

# Executar com Docker Compose
docker-compose up --build
```

---

## 🔄 Variáveis Esperadas no Conjur

| Variável no Conjur                  | Descrição                     |
|------------------------------------|-------------------------------|
| secrets-app/jwt-signing-cert       | PEM da chave privada (base64) |
| secrets-app/jwt-verification-jwk   | JWK atual (JSON base64)       |
| secrets-app/jwt-verification-jwk-previous | JWK anterior (JSON base64) |

---

## 🧪 Testes

- Testes unitários com `Surefire`
- Testes de integração com `Failsafe`
- Incluem testes para `/token` e `/validate`

---

## 📋 Interface Web

Acesse: [http://localhost:8080](http://localhost:8080)

- Botão **Gerar JWT** → Chama `/token`
- Botão **Validar** → Chama `/validate` com JWT colado no campo

---

© Projeto de laboratório para estudo de JWT, PFX e JWKs com Conjur.