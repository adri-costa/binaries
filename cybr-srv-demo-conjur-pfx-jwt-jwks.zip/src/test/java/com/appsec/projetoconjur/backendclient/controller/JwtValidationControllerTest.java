package com.appsec.projetoconjur.backendserver.cybr.srv.demo.conjur.pfxjwtjwks.controller;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.SignedJWT;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.test.web.servlet.MockMvc;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.util.Date;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Teste de integração do endpoint /validate usando MockMvc.
 * Gera um JWT assinado com chave RSA gerada dinamicamente e envia no header Authorization.
 */
@SpringBootTest
@AutoConfigureMockMvc
public class JwtValidationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private String jwt;

    @BeforeEach
    public void setup() throws Exception {
        // Geração de par de chaves RSA temporário
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair keyPair = keyGen.generateKeyPair();

        // Construção do header e payload do JWT
        JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.RS256)
            .keyID("jwt-verification-jwk")
            .type(JOSEObjectType.JWT)
            .build();

        com.nimbusds.jwt.JWTClaimsSet claims = new com.nimbusds.jwt.JWTClaimsSet.Builder()
            .subject("user")
            .issuer("test")
            .expirationTime(new Date(new Date().getTime() + 60 * 1000))
            .build();

        // Criação do JWT assinado
        SignedJWT signedJWT = new SignedJWT(header, claims);
        RSASSASigner signer = new RSASSASigner(keyPair.getPrivate());
        signedJWT.sign(signer);

        jwt = signedJWT.serialize(); // agora está assinado
    }

    @Test
    public void testValidarJwtEndpoint() throws Exception {
        mockMvc.perform(get("/validate")
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt))
            .andExpect(status().isUnauthorized()); // JWT não será validado, pois chave pública não corresponde
    }
}
