package com.appsec.projetoconjur.backendserver.cybr.srv.demo.conjur.pfxjwtjwks.controller;

import com.cyberark.conjur.api.Conjur;
import com.cyberark.conjur.api.Variables;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Teste unitário para o endpoint /token que gera JWT.
 */
@WebMvcTest(TokenController.class)
public class TokenControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private Conjur conjur;

    @BeforeEach
    public void setup() {
        Variables variables = Mockito.mock(Variables.class);
        Mockito.when(conjur.variables()).thenReturn(variables);
        Mockito.when(variables.retrieveSecret(Mockito.anyString()))
               .thenReturn("-----BEGIN PRIVATE KEY-----\nFAKEKEY\n-----END PRIVATE KEY-----");
    }

    @Test
    public void testGerarJwtEndpoint() throws Exception {
        mockMvc.perform(get("/token"))
               .andExpect(status().isOk());
    }
}
