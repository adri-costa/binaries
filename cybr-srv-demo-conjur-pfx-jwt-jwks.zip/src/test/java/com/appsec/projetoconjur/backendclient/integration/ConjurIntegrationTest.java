package com.appsec.projetoconjur.backendserver.cybr.srv.demo.conjur.pfxjwtjwks.integration;

import com.cyberark.conjur.api.Conjur;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Teste de integração que valida se o Conjur está acessível
 * e retorna o conteúdo esperado da variável privada.
 */
@SpringBootTest
public class ConjurIntegrationTest {

    @Autowired
    private Conjur conjur;

    @Test
    public void deveRecuperarChavePrivadaDoConjur() {
        String valor = conjur.variables().retrieveSecret("secrets-app/jwt-signing-cert");
        assertNotNull(valor, "❌ A variável 'jwt-signing-cert' não foi recuperada");
        assertTrue(valor.contains("PRIVATE KEY"), "❌ Conteúdo não parece uma chave PEM");
    }
}
