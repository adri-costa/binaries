package com.appsec.projetoconjur.backendserver.cybr.srv.demo.conjur.pfxjwtjwks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe principal da aplicação unificada para geração e validação de JWTs.
 */
@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
