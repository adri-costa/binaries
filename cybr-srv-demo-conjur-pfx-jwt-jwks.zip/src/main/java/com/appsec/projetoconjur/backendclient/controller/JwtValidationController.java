package com.appsec.projetoconjur.backendserver.cybr.srv.demo.conjur.pfxjwtjwks.controller;

import com.cyberark.conjur.api.Conjur;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.JWKSet;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

/**
 * Endpoint responsável por validar JWTs enviados via header Authorization.
 * A validação usa JWKs armazenados no Conjur, com fallback para a versão anterior.
 */
@RestController
@RequestMapping("/validate")
public class JwtValidationController {

    @Autowired
    private Conjur conjur;

    private final Map<String, String> kidToCurrent = new HashMap<>();
    private final Map<String, String> kidToPrevious = new HashMap<>();

    /**
     * Define os mapeamentos de KID para variáveis do Conjur (atual e anterior).
     */
    @jakarta.annotation.PostConstruct
    public void init() {
        kidToCurrent.put("1", "secrets-app/jwt-verification-jwk");
        kidToPrevious.put("1", "secrets-app/jwt-verification-jwk-previous");

        System.out.println("✅ Mapeamento de KID carregado: atual e previous");
    }

    /**
     * Valida um JWT com base no KID do header e nas chaves armazenadas no Conjur.
     */
    @GetMapping
    public ResponseEntity<String> validateJwt(HttpServletRequest request) {
        try {
            String authHeader = request.getHeader("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("❌ Header Authorization ausente ou inválido");
            }

            String token = authHeader.substring(7);
            JWSObject jws = JWSObject.parse(token);
            String kid = jws.getHeader().getKeyID();

            if (kid == null || !kidToCurrent.containsKey(kid)) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("❌ KID não reconhecido: " + kid);
            }

            if (verificaAssinatura(jws, kidToCurrent.get(kid))) {
                return ResponseEntity.ok("✅ JWT válido com chave atual (kid=" + kid + ")");
            }

            if (verificaAssinatura(jws, kidToPrevious.get(kid))) {
                return ResponseEntity.ok("✅ JWT válido com chave anterior (kid=" + kid + ")");
            }

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("❌ JWT inválido (kid=" + kid + ")");

        } catch (ParseException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("❌ Erro no parse do JWT: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("❌ Erro interno: " + e.getMessage());
        }
    }

    /**
     * Verifica a assinatura do JWT usando a variável JWK informada.
     */
    private boolean verificaAssinatura(JWSObject jwsObject, String conjurVar) {
        try {
            String jwkJson = conjur.variables().retrieveSecret(conjurVar);
            JWK jwk = JWKSet.parse("{\"keys\":[" + jwkJson + "]}").getKeys().get(0);
            RSASSAVerifier verifier = new RSASSAVerifier(jwk.toRSAKey().toRSAPublicKey());
            return jwsObject.verify(verifier);
        } catch (Exception e) {
            return false;
        }
    }
}
