package com.appsec.projetoconjur.backendserver.cybr.srv.demo.conjur.pfxjwtjwks.controller;

import com.cyberark.conjur.api.Conjur;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.StringReader;
import java.security.PrivateKey;
import java.security.Security;
import java.util.Date;

/**
 * Endpoint responsável por gerar JWT assinado com a chave privada
 * armazenada no Conjur (certificado PEM em base64).
 */
@RestController
@RequestMapping("/token")
public class TokenController {

    @Autowired
    private Conjur conjur;

    /**
     * Gera um JWT assinado com a chave armazenada no Conjur.
     * A variável usada será "secrets-app/jwt-signing-cert".
     */
    @GetMapping
    public String gerarJwt() {
        return gerarJwtComConjur("secrets-app/jwt-signing-cert");
    }

    private String gerarJwtComConjur(String varName) {
        try {
            // Recupera a chave privada (PEM) do Conjur
            String pemContent = conjur.variables().retrieveSecret(varName);

            // Converte PEM para objeto PrivateKey
            PrivateKey privateKey = extractPrivateKey(pemContent);

            // Constrói claims do JWT
            JWTClaimsSet claims = new JWTClaimsSet.Builder()
                    .issuer("backend")
                    .subject("jwt-gerado")
                    .audience("backend")
                    .issueTime(new Date())
                    .expirationTime(new Date(System.currentTimeMillis() + 10 * 60 * 1000)) // 10 min
                    .claim("scope", "jwt")
                    .build();

            // Cabeçalho com algoritmo e KID fixo "1"
            JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.RS256)
                    .type(JOSEObjectType.JWT)
                    .keyID("1")
                    .build();

            // Gera e assina o token
            SignedJWT jwt = new SignedJWT(header, claims);
            jwt.sign(new RSASSASigner(privateKey));

            return jwt.serialize();

        } catch (Exception e) {
            return "❌ Erro ao gerar JWT: " + e.getMessage();
        }
    }

    private PrivateKey extractPrivateKey(String pemContent) throws Exception {
        Security.addProvider(new BouncyCastleProvider());

        try (PEMParser parser = new PEMParser(new StringReader(pemContent))) {
            Object object = parser.readObject();
            JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");

            if (object instanceof PEMKeyPair) {
                return converter.getKeyPair((PEMKeyPair) object).getPrivate();
            } else if (object instanceof PrivateKeyInfo) {
                return converter.getPrivateKey((PrivateKeyInfo) object);
            } else {
                throw new IllegalArgumentException("❌ Formato da chave privada inválido.");
            }
        }
    }
}
