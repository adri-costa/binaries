package com.appsec.projetoconjur.backend;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(properties = {
        "spring.config.location=classpath:application-test.properties",
        "CONJUR_ACCOUNT=myConjurAccount",
        "CONJUR_APPLIANCE_URL=https://proxy",
        "CONJUR_AUTHN_API_KEY=myApiKey",
        "CONJUR_AUTHN_LOGIN=host/backend/backend-ms"
})
class BackendApplicationTests {

    @Autowired
    private Environment env;

    @Test
    void contextLoads() {
        assertThat(env.getProperty("conjur.account")).isEqualTo("myConjurAccount");
        assertThat(env.getProperty("conjur.appliance-url")).isEqualTo("https://proxy");
        assertThat(env.getProperty("conjur.authn-api-key")).isEqualTo("myApiKey");
        assertThat(env.getProperty("conjur.authn-login")).isEqualTo("host/backend/backend-ms");
        System.out.println("✅ Conjur environment loaded correctly!");
    }
}
