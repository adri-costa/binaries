package com.appsec.projetoconjur.backend.config;

import com.cyberark.conjur.api.Conjur;
import com.cyberark.conjur.api.Token;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.net.ssl.SSLContext;
import java.net.URI;
import java.nio.charset.StandardCharsets;

@Configuration
public class RunTimeInjection_ConjurConfig {

    @Value("${conjur.account}")
    private String conjurAccount;

    @Value("${conjur.applianceUrl}")
    private String conjurUrl;

    @Value("${conjur.authnApiKey}")
    private String conjurApiKey;

    @Value("${conjur.authnLogin}")
    private String conjurLogin;

    @Bean
    @Primary
    public Conjur conjur() {
        // Validação obrigatória para evitar erro de URI
        String applianceUrl = conjurUrl.trim();
        String account = conjurAccount.trim();

        if (applianceUrl.isBlank() || account.isBlank()) {
            throw new IllegalArgumentException(
                "Erro: CONJUR_APPLIANCE_URL ou CONJUR_ACCOUNT não configurados corretamente."
            );
        }

        try {
            // Valida a URL
            URI uri = URI.create(applianceUrl + "/authn/" + account);
            System.out.println("🔐 Conectando ao Conjur: " + uri);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("❌ URL inválida para o Conjur: " + applianceUrl, e);
        }

        String tokenJson = String.format(
            "{\"protected\":\"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9\",\"payload\":\"%s\",\"signature\":\"dummy\"}",
            conjurApiKey
        );
        Token token = Token.fromJson(new String(tokenJson.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8));
        return new Conjur(token, (SSLContext) null);
    }
}
