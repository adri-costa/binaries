package com.appsec.projetoconjur.backend.controller;

import com.cyberark.conjur.api.Conjur;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RunTimeInjection_CredentialController {

    @Autowired
    private Conjur conjur;

    @GetMapping("/secrets")
    public String getDbPassword(Model model) {
        // Obtendo o valor da variável 'db-password' do Conjur
        String dbPassword = conjur.variables().retrieveSecret("database/db-password");

        // Passando a senha para o modelo da página HTML
        model.addAttribute("password", dbPassword != null ? dbPassword : "Valor não encontrado");

        return "secrets";
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }
}
