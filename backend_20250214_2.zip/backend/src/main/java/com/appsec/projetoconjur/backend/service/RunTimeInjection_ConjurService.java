package com.appsec.projetoconjur.backend.service;

import com.cyberark.conjur.api.Conjur;
import org.springframework.stereotype.Service;

@Service
public class RunTimeInjection_ConjurService {

    private final Conjur conjur;

    public RunTimeInjection_ConjurService(Conjur conjur) {
        this.conjur = conjur;
    }

    public String getSecret(String variable) {
        return conjur.variables().retrieveSecret(variable);
    }
}
