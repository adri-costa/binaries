package com.appsec.projetoconjur.backend.controller;

import com.cyberark.conjur.api.Conjur;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/secrets")
public class CredentialController {

    @Autowired
    private Conjur conjur;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping(produces = MediaType.TEXT_HTML_VALUE)
    public String getDbPassword() {
        // Obtém a senha do Conjur
        String secret = conjur.variables().retrieveSecret("database/db-password");

        // Consulta no PostgreSQL
        String query = "SELECT rolname, rolpassword FROM pg_authid WHERE rolname = 'backend_user'";
        List<Map<String, Object>> result = jdbcTemplate.queryForList(query);

        // Constrói a tabela HTML
        StringBuilder htmlTable = new StringBuilder();
        htmlTable.append("<h3>🔐 Senha atual: <span style='font-weight:bold; color:blue;'>")
                 .append(secret != null ? secret : "⚠️ Senha não encontrada!")
                 .append("</span></h3>")
                 .append("<h3>Usuários e Senhas</h3>")
                 .append("<table border='1'><tr><th>Usuário</th><th>Senha (SHA-256)</th></tr>");

        for (Map<String, Object> row : result) {
            String user = (String) row.get("rolname");
            String password = (String) row.get("rolpassword");
            htmlTable.append("<tr><td>").append(user).append("</td><td>").append(password).append("</td></tr>");
        }

        htmlTable.append("</table>")
                 .append("<button onclick='window.location.reload();' style='margin-top:10px; padding:5px 10px;'>🔄 Atualizar</button>");

        return htmlTable.toString();
    }
}
