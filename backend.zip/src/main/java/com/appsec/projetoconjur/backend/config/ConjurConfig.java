package com.appsec.projetoconjur.backend.config;

import com.cyberark.conjur.api.Conjur;
import com.cyberark.conjur.api.Credentials;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

@Configuration
public class ConjurConfig {

    @Value("${CONJUR_ACCOUNT}")
    private String account;

    @Value("${CONJUR_APPLIANCE_URL}")
    private String applianceUrl;

    @Value("${CONJUR_AUTHN_LOGIN}")
    private String authnLogin;

    @Value("${CONJUR_AUTHN_API_KEY}")
    private String authnApiKey;

    @Bean
    public Conjur conjurClient() {
        disableSslVerification(); // 🚨 Desabilita a verificação SSL (ambiente de teste)

        try {
            Credentials credentials = new Credentials(authnLogin, authnApiKey);
            Conjur conjur = new Conjur(credentials);

            // Obtém as credenciais do banco de dados no Conjur
            System.setProperty("DB_USERNAME", conjur.variables().retrieveSecret("database/db-username"));
            System.setProperty("DB_PASSWORD", conjur.variables().retrieveSecret("database/db-password"));

            return conjur;
        } catch (Exception e) {
            throw new RuntimeException("❌ Falha na conexão com o Conjur", e);
        }
    }

    /**
     * Desabilita a verificação SSL para evitar erro de Trust Store em ambiente de testes.
     */
    private void disableSslVerification() {
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                public X509Certificate[] getAcceptedIssuers() { return null; }
            }}, new SecureRandom());

            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
        } catch (Exception e) {
            throw new RuntimeException("❌ Erro ao desativar SSL", e);
        }
    }
}
