package com.appsec.projetoconjur.backend.controller;

import com.cyberark.conjur.api.Conjur;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
public class CredentialController {

    @Autowired
    private Conjur conjur;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @GetMapping("/secrets")
    public String getDbPassword() {
        String dbPassword = conjur.variables().retrieveSecret("demo-conjur-postgre/password/db-password");
        String dbUser = conjur.variables().retrieveSecret("demo-conjur-postgre/token/db-username");

        // Consulta simples e segura ao banco
        String sql = "SELECT current_database() AS database, current_user AS user, now() AS timestamp";
        List<Map<String, Object>> result = jdbcTemplate.queryForList(sql);

        StringBuilder html = new StringBuilder();
        html.append("<html><body style='font-family:sans-serif;'>");
        html.append("<h2>🔐 Secrets armazenadas no Conjur</h2>");
        html.append("<p><strong>db-username:</strong> ").append(dbUser).append("</p>");
        html.append("<p><strong>db-password:</strong> ").append(dbPassword).append("</p>");

        html.append("<h2>🗄️ Consulta ao Banco de Dados utilizando as secrets acima</h2>");
        for (Map<String, Object> row : result) {
            html.append("<p>");
            html.append("Banco: ").append(row.get("database")).append(" | ");
            html.append("Usuário: ").append(row.get("user")).append(" | ");
            html.append("Hora: ").append(row.get("timestamp"));
            html.append("</p>");
        }

        html.append("</body></html>");
        return html.toString();
    }
}
