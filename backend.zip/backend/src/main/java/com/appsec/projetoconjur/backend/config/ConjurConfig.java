package com.appsec.projetoconjur.backend.config;

import com.cyberark.conjur.api.Conjur;
import com.cyberark.conjur.api.Credentials;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

@Configuration
public class ConjurConfig {

    @Value("${CONJUR_ACCOUNT}")
    private String account;

    @Value("${CONJUR_APPLIANCE_URL}")
    private String applianceUrl;

    @Value("${CONJUR_AUTHN_LOGIN}")
    private String authnLogin;

    @Value("${CONJUR_AUTHN_API_KEY}")
    private String authnApiKey;

    @Bean
    public Conjur conjurClient() {
        // ⚠️ Desativa a validação SSL antes de qualquer requisição
        disableSslVerification();

        System.out.println("🔎 DEBUG: Variáveis visíveis pelo SDK:");
        System.out.println("CONJUR_ACCOUNT: " + System.getenv("CONJUR_ACCOUNT"));
        System.out.println("CONJUR_APPLIANCE_URL: " + System.getenv("CONJUR_APPLIANCE_URL"));
        System.out.println("CONJUR_AUTHN_LOGIN: " + System.getenv("CONJUR_AUTHN_LOGIN"));
        System.out.println("CONJUR_AUTHN_API_KEY: " + System.getenv("CONJUR_AUTHN_API_KEY"));

        try {
            Credentials credentials = new Credentials(authnLogin, authnApiKey);
            Conjur conjur = new Conjur(credentials);

            // Busca e injeta variáveis no ambiente
            System.setProperty("DB_USERNAME", conjur.variables().retrieveSecret("demo-conjur-postgre/token/db-username"));
            System.setProperty("DB_PASSWORD", conjur.variables().retrieveSecret("demo-conjur-postgre/password/db-password"));

            return conjur;
        } catch (Exception e) {
            throw new RuntimeException("❌ Falha na conexão com o Conjur", e);
        }
    }

    /**
     * ⚠️ Desabilita a validação de SSL — uso exclusivo para ambiente de testes.
     */
    private void disableSslVerification() {
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, new TrustManager[]{ new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                public X509Certificate[] getAcceptedIssuers() { return null; }
            } }, new SecureRandom());

            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);

        } catch (Exception e) {
            throw new RuntimeException("❌ Erro ao desativar SSL", e);
        }
    }
}
