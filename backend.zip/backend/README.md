# 🔐 Projeto: demo-conjur-postgre

Projeto Java Spring Boot que se conecta ao **Conjur Enterprise** para buscar segredos (usuário e senha) e realizar uma conexão com um banco **PostgreSQL** externo. A senha é exibida e a conexão é testada via browser, com dados reais do banco.

---

## 📁 Estrutura do Projeto

```
api_secret/
├── backend/
│   ├── pom.xml
│   ├── rotate-db-password.sh
│   └── src/
│       └── main/
│           ├── java/com/appsec/projetoconjur/backend/
│           │   ├── BackendApplication.java
│           │   ├── config/ConjurConfig.java
│           │   └── controller/CredentialController.java
│           └── resources/
│               ├── application.properties
│               └── templates/index.html
```

---

## ☁️ Tecnologias Utilizadas

- Java 17  
- Spring Boot 3.4.2  
- PostgreSQL  
- CyberArk Conjur Enterprise 13.4.0  
- Conjur Java SDK (`conjur-api 3.0.5-SNAPSHOT`)

---

## 🔧 Funcionalidade

- Autentica no Conjur com **API Key**
- Obtém os segredos:
  - `demo-conjur-postgre/token/db-username`
  - `demo-conjur-postgre/password/db-password`
- Injeta os segredos como variáveis de sistema:
  - `DB_USERNAME`
  - `DB_PASSWORD`
- Conecta ao PostgreSQL com `JdbcTemplate`
- Exibe as credenciais e resultado da consulta SQL via HTML
- Endpoint acessível em: `http://localhost:8080/secrets`

---

## 🛡️ Políticas do Conjur

**Path:** `/policy/demo-conjur-postgre/`

### ✉️ hosts.yaml

```yaml
- !policy
  id: demo-conjur-postgre
  body:
    - !host backend
```

---

### 🔐 secrets.yaml

```yaml
- !policy
  id: demo-conjur-postgre
  body:
    - !variable password/db-password
    - !variable token/db-username
```

---

### 📢 access.yaml

```yaml
- !policy
  id: demo-conjur-postgre
  body:
    - !group postgre-readers
    - !group postgre-updaters
    - !group postgre-rotators
    - !group postgre-owners
    - !group postgre-iam

    - !grant
      role: !group postgre-readers
      member: !host backend

    - !permit
      role: !group postgre-readers
      privileges: [ read, execute ]
      resource: !variable token/db-username

    - !permit
      role: !group postgre-readers
      privileges: [ read, execute ]
      resource: !variable password/db-password

```

---

### 🛅 auth.yaml

```yaml
- !policy
  id: conjur/authn/projeto-conjur
  body:
    - !webservice
    - !variable enabled
    - !group authenticate

- !grant
  role: !group conjur/authn/projeto-conjur/authenticate
  member: !host demo-conjur-postgre/backend
```

---

### ✅ Ordem recomendada para aplicar as políticas

```bash
conjur policy load --branch root --file hosts.yaml
conjur policy load --branch root --file secrets.yaml
conjur policy load --branch root --file access.yaml
conjur policy load --branch root --file auth.yaml
```

> 💡 Após aplicar, defina os valores com:
>
> ```bash
> conjur variable set -i demo-conjur-postgre/token/db-username -v backend_user
> conjur variable set -i demo-conjur-postgre/password/db-password -v backend_pass
> ```

---

## 🐘 Configuração do Banco de Dados PostgreSQL

### ▶️ Passo a Passo:

```bash
# Acessar o usuário postgres
sudo -i -u postgres

# Acessar o shell do PostgreSQL
psql
```

```sql
-- Criar o banco de dados
CREATE DATABASE projetoconjur_db;

-- Criar o usuário com senha
CREATE USER backend_user WITH PASSWORD 'backend_pass';

-- Conceder permissões ao usuário no banco
GRANT ALL PRIVILEGES ON DATABASE projetoconjur_db TO backend_user;

-- Sair do psql
\q
```

> 📝 **Importante**:  
> - O nome do banco, usuário e senha devem coincidir com os utilizados pela aplicação.  
> - A senha será rotacionada manualmente via script e atualizada no Conjur e no PostgreSQL.

---

## ▶️ Execução

1. Configure as variáveis de ambiente:

```bash
export CONJUR_ACCOUNT=projeto-conjur
export CONJUR_APPLIANCE_URL=https://proxy:30443
export CONJUR_AUTHN_LOGIN=host/demo-conjur-postgre/backend
export CONJUR_AUTHN_API_KEY=************
```

2. Execute o projeto:

```bash
cd backend
mvn clean install spring-boot:run
```

3. Acesse:

```
http://localhost:8080/secrets
```

---

## 🔄 Roteiro de Rotação Manual de Senha

- Script: `rotate-db-password.sh`

```bash
#!/bin/bash

# ===========================================
# Script: Rotação Completa (Conjur + PostgreSQL)
# ===========================================

# Configuração do PostgreSQL
DB_HOST="host.docker.internal"  # Altere para IP se necessário
DB_PORT="5432"
DB_USER="backend_user"
DB_NAME="projetoconjur_db"
CONJUR_VAR="demo-conjur-postgre/password/db-password"

# Gerar Nova Senha
NEW_PASSWORD=$(openssl rand -base64 16 | tr -d '=+/')

# Atualizar no PostgreSQL
echo "🔄 Atualizando senha no PostgreSQL (via postgres)..."
sudo -u postgres psql -p "$DB_PORT" -d "$DB_NAME" -c "ALTER USER $DB_USER WITH PASSWORD '$NEW_PASSWORD';"

if [ $? -eq 0 ]; then
  echo "✅ PostgreSQL atualizado!"
else
  echo "❌ Falha ao atualizar PostgreSQL!"
  exit 1
fi

# Atualizar no Conjur (via kubectl)
echo "🔄 Atualizando senha no Conjur..."

kubectl exec -n conjur conjur-master-695d77d44f-jsdgf -- \
  conjur variable set --id "$CONJUR_VAR" --value "$NEW_PASSWORD"

if [ $? -eq 0 ]; then
  echo "✅ Conjur atualizado!"
else
  echo "❌ Erro ao atualizar Conjur!"
  exit 1
fi

# Registrar rotação
echo "$(date) - Senha rotacionada" >> rotation-log.txt
tail -5 rotation-log.txt
```

> 💡 O script exige permissões para executar o `psql` como usuário `postgres` e acesso ao pod do Conjur via `kubectl exec`.

---
