#!/bin/bash

# ===========================================
# Script: Rotação Completa (Conjur + PostgreSQL)
# ===========================================

# Configuração do PostgreSQL
DB_HOST="host.docker.internal"  # Altere para IP se necessário
DB_PORT="5432"
DB_USER="backend_user"
DB_NAME="projetoconjur_db"
CONJUR_VAR="demo-conjur-postgre/password/db-password"  # Caminho correto no Conjur

# Gerar Nova Senha
NEW_PASSWORD=$(openssl rand -base64 16 | tr -d '=+/')

# Atualizar no PostgreSQL
echo "🔄 Atualizando senha no PostgreSQL (via postgres)..."
sudo -u postgres psql -p "$DB_PORT" -d "$DB_NAME" -c "ALTER USER $DB_USER WITH PASSWORD '$NEW_PASSWORD';"

if [ $? -eq 0 ]; then
  echo "✅ PostgreSQL atualizado!"
else
  echo "❌ Falha ao atualizar PostgreSQL!"
  exit 1
fi

# Atualizar no Conjur (via kubectl)
echo "🔄 Atualizando senha no Conjur..."

kubectl exec -n conjur conjur-master-695d77d44f-jsdgf -- \
  conjur variable set --id "$CONJUR_VAR" --value "$NEW_PASSWORD"

if [ $? -eq 0 ]; then
  echo "✅ Conjur atualizado!"
else
  echo "❌ Erro ao atualizar Conjur!"
  exit 1
fi

# Registrar rotação
echo "$(date) - Senha rotacionada" >> rotation-log.txt
tail -5 rotation-log.txt
