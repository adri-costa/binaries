#!/bin/bash

# ===========================================
# Script: Rotação Completa (Conjur + PostgreSQL)
# ===========================================

# Configuração do PostgreSQL
DB_HOST="host.docker.internal"  # Altere para o IP se necessário
DB_PORT="5432"
DB_USER="backend_user"
DB_NAME="projetoconjur_db"
CONJUR_VAR="database/db-password"

# Gerar Nova Senha
NEW_PASSWORD=$(openssl rand -base64 16 | tr -d '=+/')

# Atualizar no PostgreSQL
echo "🔄 Atualizando senha no PostgreSQL (via postgres)..."
sudo -u postgres psql -p "$DB_PORT" -d "$DB_NAME" -c "ALTER USER $DB_USER WITH PASSWORD '$NEW_PASSWORD';"

if [ $? -eq 0 ]; then
  echo "✅ PostgreSQL atualizado!"
else
  echo "❌ Falha ao atualizar PostgreSQL!"
  exit 1
fi

# Atualizar no Conjur
echo "🔄 Atualizando senha no Conjur..."
docker compose exec client conjur variable set -i "$CONJUR_VAR" -v "$NEW_PASSWORD"
if [ $? -eq 0 ]; then
  echo "✅ Conjur atualizado!"
else
  echo "❌ Erro ao atualizar Conjur!"
  exit 1
fi

# 4️⃣ Registrar
echo "$(date) - Senha rotacionada" >> rotation-log.txt
tail -5 rotation-log.txt
