mvn install:install-file \
  -Dfile="C:\Users\garci\.m2\repository\com\cyberark\conjur-java-sdk\3.0.5-SNAPSHOT\conjur-java-sdk-3.0.5-SNAPSHOT.jar" \
  -DgroupId=com.cyberark.conjur \
  -DartifactId=conjur-api \
  -Dversion=3.0.5-SNAPSHOT \
  -Dpackaging=jar